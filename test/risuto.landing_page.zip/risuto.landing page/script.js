function friends() {
  var x = document.getElementById("friends-list");
  var y = document.getElementById("friends-btn");
  var z = document.getElementById("friends-icon");
  if (x.style.left === "8%", y.style.borderRadius === "50% 1px 50% 50%", y.style.transform === "rotate(0deg)", z.style.transform === "rotate(0deg)") {
    x.style.left = "-30%";
    y.style.borderRadius = "50%";
    y.style.transform = "rotate(-90deg)";
    z.style.transform = "rotate(90deg)";
  } else {
    x.style.left = "8%";
    y.style.borderRadius = "50% 1px 50% 50%";
    y.style.transform = "rotate(0deg)";
    z.style.transform = "rotate(0deg)";
  }
}