import Pulse from 'pulse-framework';
import React from 'react';

export const App = new Pulse({
  framework: React
});