import { App } from './pulse';

import AccountController from './controllers/account';

export const Account = AccountController;
export const AccountData = AccountController.data;