import Api from './api.service';

export default Api;