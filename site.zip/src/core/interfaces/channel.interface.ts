export interface Author {
  username: string;
}