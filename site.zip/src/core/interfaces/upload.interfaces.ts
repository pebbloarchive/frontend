export interface Upload {
  id: string;
  chunkSize: number;
  urls: [];
}