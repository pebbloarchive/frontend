import { App } from '../../pulse';
import { Posts } from './posts.actions';

export default {
  posts: Posts
  // data: PostData
}