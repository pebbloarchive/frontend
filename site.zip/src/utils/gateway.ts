export default class Gateway {
    constructor() {
        
    }
}