import Head from 'next/head';
import Nav from '../components/Nav';
import Router from 'next/router'
import { Account } from '../core';
import { AccountData } from '../core/controllers/account/account.state';
import { Log } from '..//utils';
import { usePulse } from 'pulse-framework';

const Page = () => {
    const [logged] = usePulse(Account.isUserLoggedIn);
    if(!logged && process.browser) Router.replace('/login');

    return (
        <div>
        <Head>
        <title>Pebblo Profile</title>
        </Head>
            <div>
                
            </div>
        </div>
    )
}

export default Page;