const Discord = require("discord.js");

module.exports = {
  name: "avatar",
  description: "sends user avatar!",
  execute(message, args) {
    message.react("🖼️");
    const embed = new Discord.MessageEmbed()
      .setAuthor("📷 " + message.author.username + " Avatar")
      .setImage(message.author.displayAvatarURL())
      .setColor(0x00bdff);
    message.channel.send(embed);
  }
};
