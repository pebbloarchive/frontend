const Discord = require("discord.js");

module.exports = {
  name: "app",
  description: "says app download links!",
  execute(message, args) {
    message.react("📱");
    const embed = new Discord.MessageEmbed()
      .setTitle("📱 App Download")
      .setURL(
        "https://apps.apple.com/us/app/v86-server-for-minecraft/id1490725368?uo=4"
      )
      .setColor(0x00bdff);
    message.channel.send(embed);
  }
};
