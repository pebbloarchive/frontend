const Discord = require("discord.js");

module.exports = {
  name: "server",
  description: "sends server info!",
  execute(message, args) {
    message.react("🤔")
    const embed = new Discord.MessageEmbed()
      .setTitle("Server Information")
      .addField("📝 Server Name:", message.guild.name, true)
      .addField("📅 Created At:", message.guild.createdAt, true)
      .addField("👑 Owner:", message.guild.owner, true)
      .addField("👥 Total Members", message.guild.memberCount,true)
      .addField("🙇🏻 Humans", message.guild.members.cache.filter(member => !member.user.bot).size, true)
      .addField("🤖 Bots", message.guild.members.cache.filter(member => member.user.bot).size, true)
      .addField(
        "📜 Member Status",
        `**${
          message.guild.members.cache.filter(o => o.presence.status === "online").size
        }**<:online:449590947165110283> Online\n**${
          message.guild.members.cache.filter(i => i.presence.status === "idle").size
        }**<:away:449590947110584321> Idle/Away\n**${
          message.guild.members.cache.filter(dnd => dnd.presence.status === "dnd")
            .size
        }**<:dnd:449590946879766539> Do Not Disturb\n**${
          message.guild.members.cache.filter(off => off.presence.status === "offline")
            .size
        }**<:offline:449590947047669760> Offline/Invisible`, true
      )
      .addField(
        "📍 Your Current Roles", message.member.roles.cache.map(roles => roles).join(" => "), true)
      .addField(
        "📍 All Roles:",
        message.member.roles.cache.map(roles => roles).join(" => "),
        true
      )
      .addField("🗓️ Joined At:", message.member.joinedAt, true)
      .addField("🕗 Created At:", message.author.createdAt, true)
      .setColor(0x00bdff)
      .setThumbnail(message.guild.iconURL());
    message.channel.send(embed);
  }
};