const Discord = require("discord.js");

module.exports = {
  name: "ping",
  description: "says ping!",
  execute(message, args) {
    message.react("🏓");
    var ping = Date.now() - message.createdTimestamp + " ms";
    const embed = new Discord.MessageEmbed()
      .setTitle(`Pong!`)
      .addField("📶 Latency", `${ping}`, true)
      .setColor(0x00bdff);
    message.channel.send(embed);
  }
};
