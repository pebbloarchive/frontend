const Discord = require("discord.js");

module.exports = {
  name: "profile",
  description: "sends embed profile!",
  execute(message, args) {
    let trufal = {
      true: "Robot",
      false: "Human"
    };
    message.react("🤔");
    let user;
    if (message.mentions.users.first()) {
      user = message.mentions.users.first();
    } else {
      user = message.author;
    }
    const member = message.guild.member(user);
    const embed = new Discord.MessageEmbed()
      .setTitle("User Information")
      .addField("🏷️ Username:", user.tag, true)
      .addField("💳 User ID:", user.id, true)
      .addField("🤖 Type:", trufal[user.bot], true)
      .addField("💻 Status:", user.presence.status, true)
      .addField(
        "🎮 Game:",
        `${
          user.presence.game
            ? user.presence.game.name
            : "I do not see him playing anything!"
        }`,
        true
      )
      .addField(
        "📍 All Roles:",
        member.roles.cache.map(roles => roles).join(" => "),
        true
      )
      .addField("🗓️ Joined At:", message.member.joinedAt, true)
      .addField("🕗 Created At:", user.createdAt, true)
      .setColor(0x00bdff)
      .setThumbnail(user.displayAvatarURL());
    message.channel.send(embed);
  }
};
