const Discord = require("discord.js");

module.exports = {
  name: "poll",
  description: "creates a poll to react!",
  execute(message, args) {
    let saying = args.slice(1).join(" ");
    if (!saying) return message.reply("📝 Please respond with text");

    const embed = new Discord.MessageEmbed()
      .setColor(0x00bdff)
      .setFooter("React to vote")
      .setDescription("📋 " + saying)
      .setTitle(`Poll created by ${message.author.username}`);

    message.channel.send(embed).then(messageReaction => {
      messageReaction.react("👍");
      messageReaction.react("👎");
      message.delete({ timeout: 1000 }).catch(console.error);
    });
  }
};
