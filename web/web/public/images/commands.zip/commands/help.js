const Discord = require("discord.js");

module.exports = {
  name: "help",
  description: "sends a help list in chat!",
  execute(message, args) {
    message.react("📬");
    let pages = [
      `
<a:tools:713106917341397115> **General Commands** <a:tools:713106917341397115> 
 - v!info
 - v!website
 - v!app
 - v!say
 - v!emojify
 - v!serverinfo
 - v!weather
`,
      `
<a:performing_arts:713107070915969145> **Utility & Fun** <a:performing_arts:713107070915969145>
 - v!profile
 - v!avatar
 - v!minecraft
`,
      `
<a:crown:713106662457737298> **Moderator & Developer** <a:crown:713106662457737298> 
 - v!ping
 - v!uptime
 - v!poll
 - v!hastebin
 - v!stats



`
    ];

    let page = 1;

    const embed = new Discord.MessageEmbed()
      .setDescription(pages[page - 1])
      .setColor(0x00bdff)
      .setFooter(`Page ${page} Of ${pages.length}`);

    message.channel.send(embed).then(msg => {
      msg.react(`⏪`).then(r => {
        msg.react(`⏩`);
        const backwardsFilter = (reaction, user) =>
          reaction.emoji.name === `⏪` && user.id === message.author.id;
        const forwardsFilter = (reaction, user) =>
          reaction.emoji.name === `⏩` && user.id === message.author.id;
        const backwards = msg.createReactionCollector(backwardsFilter, {
          time: 600000
        });
        const forwards = msg.createReactionCollector(forwardsFilter, {
          time: 600000
        });
        backwards.on("collect", r => {
          if (page === 1) return;
          page--;
          embed.setDescription(pages[page - 1]);
          embed.setFooter(`Page ${page} Of ${pages.length}`);
          msg.edit(embed);
        });
        forwards.on("collect", r => {
          if (page === pages.length) return;
          page++;
          embed.setDescription(pages[page - 1]);
          embed.setFooter(`Page ${page} Of ${pages.length}`);
          msg.edit(embed);
        });
      });
    });
  }
};
