const Discord = require("discord.js");

module.exports = {
  name: "website",
  description: "says website!",
  execute(message, args) {
    message.react("🖥️");
    const embed = new Discord.MessageEmbed()
      .setTitle("App Website")
      .setURL("https://mineserver.io")
      .setColor(0x00bdff);
    message.channel.send(embed);
  }
};
