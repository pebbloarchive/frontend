const Discord = require("discord.js");

module.exports = {
  name: "info",
  description: "says info!",
  execute(message, args, client) {
    message.react("💡");
    const embed = new Discord.MessageEmbed()
      .setTitle("Bot Information")
      .setColor(0x00bdff)
      .addField("🏷️ Bot Name:", "v86.co", true)
      .addField("👑 Creator:", "Tinplex", true)
      .addField("⌚ Created At:", "2020 May 30th")
      .setThumbnail(client.user.displayAvatarURL());
    message.channel.send(embed);
  }
};
